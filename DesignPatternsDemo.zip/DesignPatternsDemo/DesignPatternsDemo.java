import java.util.*;

// ======================= BEHAVIORAL: OBSERVER PATTERN =======================
interface Observer {
    void update(String stock, double price);
}

class Investor implements Observer {
    private String name;
    public Investor(String name) { this.name = name; }
    @Override
    public void update(String stock, double price) {
        System.out.println(name + " notified: " + stock + " price changed to " + price);
    }
}

class StockMarket {
    private Map<String, Double> stocks = new HashMap<>();
    private List<Observer> investors = new ArrayList<>();

    public void addObserver(Observer o) { investors.add(o); }
    public void removeObserver(Observer o) { investors.remove(o); }
    public void setStockPrice(String stock, double price) {
        stocks.put(stock, price);
        notifyObservers(stock, price);
    }
    private void notifyObservers(String stock, double price) {
        for (Observer o : investors) { o.update(stock, price); }
    }
}

// ======================= BEHAVIORAL: STRATEGY PATTERN =======================
interface PaymentMethod {
    void pay(double amount);
}

class CreditCardPayment implements PaymentMethod {
    @Override
    public void pay(double amount) { System.out.println("Paid " + amount + " using Credit Card."); }
}

class PayPalPayment implements PaymentMethod {
    @Override
    public void pay(double amount) { System.out.println("Paid " + amount + " using PayPal."); }
}

class UPIPayment implements PaymentMethod {
    @Override
    public void pay(double amount) { System.out.println("Paid " + amount + " using UPI."); }
}

class ShoppingCart {
    private PaymentMethod paymentMethod;
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    public void checkout(double amount) { paymentMethod.pay(amount); }
}

// ======================= CREATIONAL: SINGLETON PATTERN =======================
class Logger {
    private static Logger instance;
    private Logger() {}
    public static Logger getInstance() {
        if(instance == null) instance = new Logger();
        return instance;
    }
    public void log(String message) { System.out.println("LOG: " + message); }
}

// ======================= CREATIONAL: FACTORY PATTERN =======================
interface Shape { void draw(); }
class Circle implements Shape { @Override public void draw() { System.out.println("Drawing Circle"); } }
class Rectangle implements Shape { @Override public void draw() { System.out.println("Drawing Rectangle"); } }
class Triangle implements Shape { @Override public void draw() { System.out.println("Drawing Triangle"); } }
class ShapeFactory {
    public Shape getShape(String shapeType) {
        switch(shapeType.toLowerCase()) {
            case "circle": return new Circle();
            case "rectangle": return new Rectangle();
            case "triangle": return new Triangle();
            default: return null;
        }
    }
}

// ======================= STRUCTURAL: ADAPTER PATTERN =======================
interface MediaPlayer { void play(String audioType, String fileName); }
class Mp4Player { public void playMp4(String fileName) { System.out.println("Playing mp4 file: " + fileName); } }
class VlcPlayer { public void playVlc(String fileName) { System.out.println("Playing vlc file: " + fileName); } }
class MediaAdapter implements MediaPlayer {
    private Mp4Player mp4Player;
    private VlcPlayer vlcPlayer;
    public MediaAdapter(String audioType) {
        if(audioType.equalsIgnoreCase("mp4")) mp4Player = new Mp4Player();
        else if(audioType.equalsIgnoreCase("vlc")) vlcPlayer = new VlcPlayer();
    }
    @Override
    public void play(String audioType, String fileName) {
        if(audioType.equalsIgnoreCase("mp4")) mp4Player.playMp4(fileName);
        else if(audioType.equalsIgnoreCase("vlc")) vlcPlayer.playVlc(fileName);
    }
}

// ======================= STRUCTURAL: DECORATOR PATTERN =======================
interface Coffee { double cost(); String ingredients(); }
class SimpleCoffee implements Coffee { 
    @Override public double cost() { return 5.0; }
    @Override public String ingredients() { return "Coffee"; }
}
abstract class CoffeeDecorator implements Coffee {
    protected Coffee decoratedCoffee;
    public CoffeeDecorator(Coffee coffee) { this.decoratedCoffee = coffee; }
}
class Milk extends CoffeeDecorator {
    public Milk(Coffee coffee) { super(coffee); }
    @Override public double cost() { return decoratedCoffee.cost() + 2; }
    @Override public String ingredients() { return decoratedCoffee.ingredients() + ", Milk"; }
}
class Sugar extends CoffeeDecorator {
    public Sugar(Coffee coffee) { super(coffee); }
    @Override public double cost() { return decoratedCoffee.cost() + 1; }
    @Override public String ingredients() { return decoratedCoffee.ingredients() + ", Sugar"; }
}
class WhippedCream extends CoffeeDecorator {
    public WhippedCream(Coffee coffee) { super(coffee); }
    @Override public double cost() { return decoratedCoffee.cost() + 3; }
    @Override public String ingredients() { return decoratedCoffee.ingredients() + ", WhippedCream"; }
}

// ======================= MAIN DEMO =======================
public class DesignPatternsDemo {
    public static void main(String[] args) {
        System.out.println("=== Observer Pattern ===");
        StockMarket market = new StockMarket();
        Investor investor1 = new Investor("Alice");
        Investor investor2 = new Investor("Bob");
        market.addObserver(investor1);
        market.addObserver(investor2);
        market.setStockPrice("AAPL", 150.0);
        market.setStockPrice("GOOG", 2800.0);

        System.out.println("\n=== Strategy Pattern ===");
        ShoppingCart cart = new ShoppingCart();
        cart.setPaymentMethod(new CreditCardPayment());
        cart.checkout(500);
        cart.setPaymentMethod(new PayPalPayment());
        cart.checkout(300);

        System.out.println("\n=== Singleton Pattern ===");
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        logger1.log("First message");
        System.out.println("logger1 == logger2? " + (logger1 == logger2));

        System.out.println("\n=== Factory Pattern ===");
        ShapeFactory factory = new ShapeFactory();
        Shape circle = factory.getShape("circle");
        Shape rectangle = factory.getShape("rectangle");
        circle.draw();
        rectangle.draw();

        System.out.println("\n=== Adapter Pattern ===");
        MediaPlayer player = new MediaAdapter("mp4");
        player.play("mp4", "song.mp4");
        player = new MediaAdapter("vlc");
        player.play("vlc", "movie.vlc");

        System.out.println("\n=== Decorator Pattern ===");
        Coffee coffee = new SimpleCoffee();
        coffee = new Milk(coffee);
        coffee = new Sugar(coffee);
        coffee = new WhippedCream(coffee);
        System.out.println("Ingredients: " + coffee.ingredients());
        System.out.println("Total cost: " + coffee.cost());
    }
}
