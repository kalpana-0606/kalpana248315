public interface GridComponent {
    boolean isOccupied(int x, int y);
}

