import java.util.List;

public class MarsRoverApp {
    public static void main(String[] args) {
        // Initialize Grid
        Grid grid = new Grid(10, 10);
        grid.addObstacle(new Cell(2, 2));
        grid.addObstacle(new Cell(3, 5));

        // Initialize Rover
        Rover rover = new Rover(0, 0, Direction.N, grid);

        // Define Commands
        List<Command> commands = List.of(
            new MoveCommand(rover),
            new MoveCommand(rover),
            new RightCommand(rover),
            new MoveCommand(rover),
            new LeftCommand(rover),
            new MoveCommand(rover)
        );

        // Execute Commands
        commands.forEach(Command::execute);

        // Print Status
        System.out.println(rover.statusReport());
    }
}
