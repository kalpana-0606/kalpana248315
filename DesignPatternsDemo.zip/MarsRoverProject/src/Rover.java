public class Rover {
    private int x, y;
    private Direction direction;
    private final Grid grid;

    public Rover(int x, int y, Direction direction, Grid grid) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.grid = grid;
    }

    public void move() {
        int nextX = x, nextY = y;
        switch(direction) {
            case N -> nextY++;
            case S -> nextY--;
            case E -> nextX++;
            case W -> nextX--;
        }
        if (!grid.isOccupied(nextX, nextY)) {
            x = nextX;
            y = nextY;
        }
    }

    public void turnLeft() {
        direction = direction.turnLeft();
    }

    public void turnRight() {
        direction = direction.turnRight();
    }

    public String statusReport() {
        return String.format("Rover is at (%d, %d) facing %s.", x, y, direction);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public Direction getDirection() { return direction; }
}
