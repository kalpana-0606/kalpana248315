public class Cell implements GridComponent {
    private final int x, y;
    private boolean occupied;

    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        this.occupied = true; // obstacle cell is occupied
    }

    @Override
    public boolean isOccupied(int x, int y) {
        return this.x == x && this.y == y && occupied;
    }
}

