import java.util.ArrayList;
import java.util.List;

public class Grid implements GridComponent {
    private final int width, height;
    private final List<GridComponent> obstacles = new ArrayList<>();

    public Grid(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void addObstacle(GridComponent obstacle) {
        obstacles.add(obstacle);
    }

    @Override
    public boolean isOccupied(int x, int y) {
        if (x < 0 || y < 0 || x >= width || y >= height) return true;
        return obstacles.stream().anyMatch(o -> o.isOccupied(x, y));
    }
}

